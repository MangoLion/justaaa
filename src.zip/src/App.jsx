import { useState } from 'react'
import './App.css'
import ImageGallery from './ProjectGallery'

function App() {

  return <ImageGallery />
}

export default App
